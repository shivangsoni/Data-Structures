#!/bin/bash
./consistentresultverification.exe $1
