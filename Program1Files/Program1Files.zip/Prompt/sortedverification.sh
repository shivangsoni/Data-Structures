#!/bin/bash
./sortedverification.exe $1
